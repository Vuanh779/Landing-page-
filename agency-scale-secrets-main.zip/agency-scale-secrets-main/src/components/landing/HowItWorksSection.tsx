import { BookOpen, Settings, TrendingUp } from "lucide-react";

const steps = [
  {
    number: "1",
    icon: BookOpen,
    title: "Master Our Proven Ad Templates",
    subtitle: "Learn the Mad Lib Ads",
    description: "Get the exact Facebook and YouTube ad templates that generate leads"
  },
  {
    number: "2",
    icon: Settings,
    title: "Set Up Your Client Acquisition Machine",
    subtitle: "Implement the System",
    description: "Use our automation and processes to streamline everything"
  },
  {
    number: "3",
    icon: TrendingUp,
    title: "Grow to $25K+/Month Predictably",
    subtitle: "Scale & Optimize",
    description: "Follow our scaling blueprint to consistently grow your revenue"
  }
];

const HowItWorksSection = () => {
  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
            How Our System Works
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            In 3 simple steps, here's how our system transforms your agency
          </p>
        </div>
        
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-3 gap-8">
            {steps.map((step, index) => (
              <div key={index} className="relative">
                {/* Connection Line */}
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-16 left-full w-8 h-px bg-gradient-primary z-0"></div>
                )}
                
                <div className="bg-card rounded-2xl p-8 shadow-elegant border border-border hover:shadow-primary transition-all duration-300 text-center relative z-10">
                  {/* Step Number */}
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-primary rounded-full text-primary-foreground font-bold text-2xl mb-6">
                    {step.number}
                  </div>
                  
                  {/* Icon */}
                  <div className="inline-flex items-center justify-center w-20 h-20 bg-accent/10 rounded-full mb-6">
                    <step.icon size={40} className="text-accent" />
                  </div>
                  
                  <h3 className="text-xl font-bold text-card-foreground mb-2">
                    {step.title}
                  </h3>
                  
                  <h4 className="text-lg font-semibold text-primary mb-4">
                    {step.subtitle}
                  </h4>
                  
                  <p className="text-muted-foreground leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;