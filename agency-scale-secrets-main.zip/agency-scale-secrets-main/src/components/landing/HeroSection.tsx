import { Button } from "@/components/ui/button";
import { Play } from "lucide-react";

const HeroSection = () => {
  return (
    <section className="relative min-h-screen geometric-bg flex items-center justify-center text-center text-primary-foreground overflow-hidden">
      {/* Animated Floating Shapes */}
      <div className="floating-shapes">
        <div className="shape"></div>
        <div className="shape"></div>
        <div className="shape"></div>
        <div className="shape"></div>
      </div>
      
      {/* Additional Geometric Elements */}
      <div className="absolute inset-0 opacity-20">
        {/* Diagonal Lines */}
        <div className="absolute top-0 left-0 w-full h-full">
          <div className="absolute top-1/4 left-0 w-full h-px bg-gradient-to-r from-transparent via-white/30 to-transparent transform rotate-12"></div>
          <div className="absolute top-3/4 left-0 w-full h-px bg-gradient-to-r from-transparent via-white/30 to-transparent transform -rotate-12"></div>
        </div>
        
        {/* Corner Decorations */}
        <div className="absolute top-10 right-10 w-32 h-32 border border-white/20 rounded-full animate-pulse"></div>
        <div className="absolute bottom-10 left-10 w-24 h-24 border border-white/20 transform rotate-45 animate-pulse"></div>
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
            Scale Your Digital Agency to{" "}
            <span className="text-accent">$25K+/Month</span>{" "}
            in 90 Days or Less
          </h1>
          
          <p className="text-xl md:text-2xl mb-8 opacity-90 max-w-3xl mx-auto leading-relaxed">
            Discover the proven system that helped 500+ agency owners build profitable 
            Facebook Ads and lead generation agencies - even if you're starting from $0
          </p>
          
          <div className="mb-12">
            <a 
              href="https://www.youtube.com/@agencyscalingsecrets" 
              target="_blank" 
              rel="noopener noreferrer"
            >
              <Button variant="accent" size="lg" className="px-8 py-4 text-xl">
                <Play className="mr-2" size={24} />
                Watch Free Training Now
              </Button>
            </a>
          </div>
          
          {/* Demo Video Placeholder */}
          <div className="max-w-4xl mx-auto">
            <div className="relative bg-black/20 rounded-2xl p-8 backdrop-blur-sm border border-white/20">
              <div className="aspect-video bg-black/50 rounded-xl flex items-center justify-center">
                <div className="text-center">
                  <Play size={64} className="mx-auto mb-4 text-accent" />
                  <h3 className="text-2xl font-semibold mb-2">
                    Demo Video (2-3 minutes)
                  </h3>
                  <p className="text-lg opacity-80">
                    "What if I told you that you could build a $25,000/month agency 
                    in the next 90 days using the exact same system I used to scale CoolBeans Digital?"
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/50 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white/50 rounded-full mt-2"></div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;