import { TrendingUp, DollarSign, FileText } from "lucide-react";

const benefits = [
  {
    icon: TrendingUp,
    title: "Get 4-8 New Clients Every Month",
    subtitle: "Predictable Revenue",
    description: "Never worry about where your next client is coming from"
  },
  {
    icon: DollarSign,
    title: "Achieve 75%+ Profit Margins",
    subtitle: "Higher Profit Margins",
    description: "Work less while earning significantly more"
  },
  {
    icon: FileText,
    title: "Copy Our Exact Templates & Scripts",
    subtitle: "Proven System",
    description: "No guesswork - just follow our proven playbook"
  }
];

const BenefitsSection = () => {
  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
            Transform Your Agency with Proven Benefits
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Features tell, but benefits sell. Here's what you'll achieve with our system.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {benefits.map((benefit, index) => (
            <div 
              key={index}
              className="text-center bg-card rounded-2xl p-8 shadow-elegant border border-border hover:shadow-primary transition-all duration-300 group"
            >
              <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-primary rounded-full mb-6 group-hover:scale-110 transition-transform duration-300">
                <benefit.icon size={40} className="text-primary-foreground" />
              </div>
              
              <h3 className="text-2xl font-bold text-card-foreground mb-2">
                {benefit.title}
              </h3>
              
              <h4 className="text-lg font-semibold text-primary mb-4">
                {benefit.subtitle}
              </h4>
              
              <p className="text-muted-foreground leading-relaxed">
                {benefit.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BenefitsSection;