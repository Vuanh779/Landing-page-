import { Button } from "@/components/ui/button";
import { Check, Star } from "lucide-react";

const plans = [
  {
    name: "Basic Plan",
    badge: "FREE",
    price: "$0",
    features: [
      "Free training video",
      "Basic templates",
      "Community access",
      "Email support"
    ],
    cta: "Start Free",
    variant: "outline" as const,
    popular: false
  },
  {
    name: "Pro Plan",
    badge: "MOST POPULAR",
    price: "$297",
    period: "/month",
    features: [
      "Complete Agency BTS Masterclass",
      "All templates and scripts",
      "Live client pitch recordings",
      "Private coaching calls",
      "Done-for-you automation"
    ],
    cta: "Join Pro Now",
    variant: "hero" as const,
    popular: true
  },
  {
    name: "Elite Plan",
    badge: "PREMIUM",
    price: "$997",
    period: "/month",
    features: [
      "Everything in Pro",
      "1-on-1 coaching with Jeff",
      "Done-with-you client calls",
      "VIP support",
      "Profit sharing opportunities"
    ],
    cta: "Go Elite",
    variant: "accent" as const,
    popular: false
  }
];

const PricingSection = () => {
  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
            Choose Your Path to Agency Success
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Select the plan that best fits your current situation and growth goals
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <div 
              key={index}
              className={`relative bg-card rounded-2xl p-8 border transition-all duration-300 ${
                plan.popular 
                  ? 'border-primary shadow-primary scale-105' 
                  : 'border-border shadow-elegant hover:shadow-primary'
              }`}
            >
              {/* Popular Badge */}
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-gradient-accent text-accent-foreground px-4 py-2 rounded-full text-sm font-bold flex items-center gap-1">
                    <Star size={16} />
                    {plan.badge}
                  </div>
                </div>
              )}
              
              {!plan.popular && (
                <div className="text-center mb-4">
                  <span className="bg-muted text-muted-foreground px-3 py-1 rounded-full text-sm font-medium">
                    {plan.badge}
                  </span>
                </div>
              )}
              
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-card-foreground mb-4">
                  {plan.name}
                </h3>
                <div className="mb-6">
                  <span className="text-5xl font-bold text-card-foreground">
                    {plan.price}
                  </span>
                  {plan.period && (
                    <span className="text-muted-foreground text-lg">
                      {plan.period}
                    </span>
                  )}
                </div>
              </div>
              
              <div className="space-y-4 mb-8">
                {plan.features.map((feature, featureIndex) => (
                  <div key={featureIndex} className="flex items-start gap-3">
                    <Check size={20} className="text-success mt-1 flex-shrink-0" />
                    <span className="text-card-foreground">{feature}</span>
                  </div>
                ))}
              </div>
              
              <Button 
                variant={plan.variant} 
                size="lg" 
                className="w-full"
              >
                {plan.cta}
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PricingSection;