import { X, Check } from "lucide-react";

const ComparisonSection = () => {
  return (
    <section className="py-20 bg-muted/50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
            Old Way vs New Way
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Stop struggling with outdated methods. Embrace the systematic approach that actually works.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {/* Old Way */}
          <div className="bg-card rounded-2xl p-8 border-2 border-destructive/20">
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-destructive/10 rounded-full mb-4">
                <X size={32} className="text-destructive" />
              </div>
              <h3 className="text-2xl font-bold text-destructive mb-2">
                The Frustrating Reality
              </h3>
              <p className="text-lg text-muted-foreground">
                Why Most Agencies Fail
              </p>
            </div>
            
            <div className="space-y-4">
              {[
                "Struggling to find clients consistently",
                "Working 80+ hours a week for minimal profit",
                "Competing on price instead of value",
                "No proven system or processes"
              ].map((point, index) => (
                <div key={index} className="flex items-start gap-3">
                  <X size={20} className="text-destructive mt-1 flex-shrink-0" />
                  <span className="text-card-foreground">{point}</span>
                </div>
              ))}
            </div>
          </div>
          
          {/* New Way */}
          <div className="bg-card rounded-2xl p-8 border-2 border-success/20 shadow-lg">
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-success/10 rounded-full mb-4">
                <Check size={32} className="text-success" />
              </div>
              <h3 className="text-2xl font-bold text-success mb-2">
                The Proven Solution
              </h3>
              <p className="text-lg text-muted-foreground">
                Our Systematic Approach
              </p>
            </div>
            
            <div className="space-y-4">
              {[
                "Predictable client acquisition system",
                "High-profit margins (75%+)",
                "Scalable processes and automation",
                "Proven templates and scripts"
              ].map((point, index) => (
                <div key={index} className="flex items-start gap-3">
                  <Check size={20} className="text-success mt-1 flex-shrink-0" />
                  <span className="text-card-foreground font-medium">{point}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
        
        <div className="text-center mt-12 max-w-4xl mx-auto">
          <div className="bg-card rounded-2xl p-8 shadow-elegant">
            <p className="text-lg text-muted-foreground mb-4">
              <strong className="text-destructive">The Problem:</strong> Most agency owners are stuck in the feast-or-famine cycle, desperately chasing clients and competing on price.
            </p>
            <p className="text-lg text-foreground">
              <strong className="text-success">The Solution:</strong> Our Agency Scaling Secrets system gives you a predictable way to attract 4-8 high-paying clients every month using our proven Facebook and YouTube ad templates.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ComparisonSection;