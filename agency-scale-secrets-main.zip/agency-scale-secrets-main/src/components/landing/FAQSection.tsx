import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "How quickly can I see results?",
    answer: "Most students get their first client within 30 days of implementing our system. The exact timeline depends on your commitment level and how consistently you follow our proven methodology."
  },
  {
    question: "Do I need experience with Facebook Ads?",
    answer: "No! Our Mad Lib templates make it simple for complete beginners. We provide step-by-step instructions and proven ad templates that you can customize for any industry."
  },
  {
    question: "What if I don't have any clients yet?",
    answer: "Perfect! Our system is designed for people starting from $0. We'll show you exactly how to position yourself as an expert and attract your first clients quickly."
  },
  {
    question: "Is there a money-back guarantee?",
    answer: "Yes, we offer a 30-day money-back guarantee on all paid programs. If you're not completely satisfied with the training and results, we'll refund your investment."
  }
];

const FAQSection = () => {
  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
            Frequently Asked Questions
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Simple answers to common questions about our agency scaling system
          </p>
        </div>
        
        <div className="max-w-4xl mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="bg-card rounded-2xl border border-border shadow-elegant px-6"
              >
                <AccordionTrigger className="text-left text-lg font-semibold text-card-foreground hover:text-primary">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed pt-2 pb-4">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
};

export default FAQSection;