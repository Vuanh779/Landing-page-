import { Star } from "lucide-react";

const testimonials = [
  {
    text: "Made $15K in my first month",
    author: "Sarah K.",
    rating: 5
  },
  {
    text: "Went from $0 to $30K/month in 6 months",
    author: "Mike R.",
    rating: 5
  },
  {
    text: "Finally have a system that works consistently",
    author: "Lisa T.",
    rating: 5
  },
  {
    text: "The Mad Lib Ads changed everything for my agency",
    author: "David M.",
    rating: 5
  }
];

const SocialProofSection = () => {
  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
            Join 500+ Successful Agency Owners
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Real results from real students who transformed their agencies using our proven system
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <div 
              key={index}
              className="bg-card rounded-2xl p-6 shadow-elegant border border-border hover:shadow-primary transition-all duration-300"
            >
              <div className="flex mb-4">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star key={i} size={20} className="fill-accent text-accent" />
                ))}
              </div>
              <blockquote className="text-lg font-medium text-card-foreground mb-4">
                "{testimonial.text}"
              </blockquote>
              <cite className="text-muted-foreground font-semibold">
                - {testimonial.author}
              </cite>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SocialProofSection;