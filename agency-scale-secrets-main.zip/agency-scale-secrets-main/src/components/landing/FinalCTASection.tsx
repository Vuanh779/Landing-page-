import { Button } from "@/components/ui/button";
import { Play, ArrowRight } from "lucide-react";

const FinalCTASection = () => {
  return (
    <section className="py-20 geometric-bg relative overflow-hidden">
      {/* Animated Floating Shapes */}
      <div className="floating-shapes">
        <div className="shape"></div>
        <div className="shape"></div>
      </div>
      
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="w-full h-full bg-white/10" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.2'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center max-w-4xl mx-auto text-primary-foreground">
          <h2 className="text-5xl md:text-6xl font-bold mb-6">
            Ready to Scale Your Agency?
          </h2>
          
          <p className="text-xl md:text-2xl mb-8 opacity-90 leading-relaxed">
            Join thousands of successful agency owners who have transformed their businesses 
            with our proven system. Your $25K+ month is waiting.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <a 
              href="https://www.youtube.com/@agencyscalingsecrets" 
              target="_blank" 
              rel="noopener noreferrer"
            >
              <Button variant="accent" size="lg" className="px-8 py-4 text-xl">
                <Play className="mr-2" size={24} />
                Watch the Free Training Now
              </Button>
            </a>
            
            <Button variant="outline" size="lg" className="px-8 py-4 text-xl bg-white/10 border-white/30 text-white hover:bg-white/20">
              Get Started Today
              <ArrowRight className="ml-2" size={24} />
            </Button>
          </div>
          
          <div className="mt-8 text-lg opacity-80">
            <p>🔥 <strong>Limited Time:</strong> Free training includes bonus case studies</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FinalCTASection;