import { Facebook, Youtube, Users, BookOpen } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-foreground text-background py-16">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          {/* Logo & Description */}
          <div className="md:col-span-2">
            <h3 className="text-2xl font-bold mb-4">Agency Scaling Secrets</h3>
            <p className="text-background/80 leading-relaxed mb-6">
              The proven system that helps digital agency owners scale to $25K+/month 
              with predictable client acquisition and high-profit margins.
            </p>
            
            {/* Social Proof Stats */}
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <Users size={24} className="text-accent" />
                </div>
                <div className="text-sm font-semibold">Join 10,000+</div>
                <div className="text-xs text-background/70">Agency Owners</div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <Youtube size={24} className="text-accent" />
                </div>
                <div className="text-sm font-semibold">500+ Free</div>
                <div className="text-xs text-background/70">Training Videos</div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <BookOpen size={24} className="text-accent" />
                </div>
                <div className="text-sm font-semibold">Read More</div>
                <div className="text-xs text-background/70">Success Stories</div>
              </div>
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-background/80">
              <li><a href="#" className="hover:text-accent transition-colors">Free Training</a></li>
              <li><a href="#" className="hover:text-accent transition-colors">Success Stories</a></li>
              <li><a href="#" className="hover:text-accent transition-colors">Pricing</a></li>
              <li><a href="#" className="hover:text-accent transition-colors">FAQ</a></li>
            </ul>
          </div>
          
          {/* Legal */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Legal</h4>
            <ul className="space-y-2 text-background/80">
              <li><a href="#" className="hover:text-accent transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-accent transition-colors">Terms of Service</a></li>
              <li><a href="#" className="hover:text-accent transition-colors">Refund Policy</a></li>
              <li><a href="#" className="hover:text-accent transition-colors">Contact</a></li>
            </ul>
          </div>
        </div>
        
        {/* Social Media & Contact */}
        <div className="border-t border-background/20 pt-8 flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center gap-4 mb-4 md:mb-0">
            <a 
              href="#" 
              className="flex items-center justify-center w-10 h-10 bg-background/10 rounded-full hover:bg-accent transition-colors"
            >
              <Facebook size={20} />
            </a>
            <a 
              href="#" 
              className="flex items-center justify-center w-10 h-10 bg-background/10 rounded-full hover:bg-accent transition-colors"
            >
              <Youtube size={20} />
            </a>
          </div>
          
          <div className="text-center md:text-right">
            <p className="text-background/80 text-sm mb-2">
              © 2024 Agency Scaling Secrets. All rights reserved.
            </p>
            <p className="text-background/60 text-xs">
              Contact: support@agencyscalingsecrets.com
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;